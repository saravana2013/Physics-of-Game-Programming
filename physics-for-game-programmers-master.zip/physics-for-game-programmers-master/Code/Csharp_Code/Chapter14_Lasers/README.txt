Compile commands  

csc LaserSimulator.cs

