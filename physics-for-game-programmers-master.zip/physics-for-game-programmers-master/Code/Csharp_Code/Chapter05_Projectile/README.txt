Compile commands  

csc GolfGame.cs SimpleProjectile.cs ODE.cs

csc GolfGame2.cs DragProjectile.cs SimpleProjectile.cs ODE.cs ODESolver.cs

csc GolfGame3.cs WindProjectile.cs DragProjectile.cs SimpleProjectile.cs ODE.cs ODESolver.cs

csc GolfGame4.cs SpinProjectile.cs WindProjectile.cs DragProjectile.cs SimpleProjectile.cs ODE.cs ODESolver.cs




