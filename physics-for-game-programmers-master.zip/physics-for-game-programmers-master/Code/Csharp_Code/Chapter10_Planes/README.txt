Compile commands  

csc FlightSimulator.cs CessnaSkyhawk.cs PropPlane.cs SimpleProjectile.cs ODE.cs ODESolver.cs


