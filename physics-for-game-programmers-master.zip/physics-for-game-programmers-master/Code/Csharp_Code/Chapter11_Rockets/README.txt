Compile commands  

csc RocketSimulator.cs SimpleRocket.cs ODE.cs USatm76.cs ODESolver.cs


