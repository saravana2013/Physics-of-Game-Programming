Compile commands  

csc BoatSimulator.cs FountainLightning.cs Powerboat.cs SimpleProjectile.cs ODE.cs ODESolver.cs


