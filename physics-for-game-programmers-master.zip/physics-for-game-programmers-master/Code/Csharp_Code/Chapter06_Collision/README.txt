Compile commands  

csc SphereCollision.cs

csc PaddleGame.cs

Note on C# Version of PaddleGame: The Windows.Forms namespace
doesn't seem to have a Slider component, so with the C# version
of the PaddleGame the paddle is moved up or down simply by
clicking on the location where you want the paddle to go.

