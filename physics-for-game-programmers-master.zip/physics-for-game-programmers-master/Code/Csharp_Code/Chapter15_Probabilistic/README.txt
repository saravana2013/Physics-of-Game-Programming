Compile commands  

csc SoldierGame.cs Soldier.cs

csc PiEstimator.cs

