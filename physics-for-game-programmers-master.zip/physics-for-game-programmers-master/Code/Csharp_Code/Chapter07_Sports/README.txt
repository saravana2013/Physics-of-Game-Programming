Compile commands  

csc GolfGame.cs GolfBall.cs SpinProjectile.cs WindProjectile.cs DragProjectile.cs SimpleProjectile.cs ODE.cs ODESolver.cs

csc FreeKick.cs SoccerBall.cs SpinProjectile.cs WindProjectile.cs DragProjectile.cs SimpleProjectile.cs ODE.cs ODESolver.cs

