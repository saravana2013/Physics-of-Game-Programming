Compile commands  

csc GasTankSimulator.cs GasTank.cs


