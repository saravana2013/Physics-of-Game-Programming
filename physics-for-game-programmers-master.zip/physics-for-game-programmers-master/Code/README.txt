Hello Readers,

One major difference between the C versions
of the examples and the Java or C# versions
is that the C examples don't have GUIs. 
The reason for this is that I don't know how
to write a GUI in C. The "guts" of the examples
are more or less the same but instead of displaying
the results in a GUI, the results from the C
programs are written to the screen.

