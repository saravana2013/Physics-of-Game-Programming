Compile commands  

javac SoldierGame.java
javac PiEstimator.java

