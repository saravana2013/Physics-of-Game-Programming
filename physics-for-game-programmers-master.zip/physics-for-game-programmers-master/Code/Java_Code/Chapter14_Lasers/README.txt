Compile commands  

javac LaserSimulator.java

