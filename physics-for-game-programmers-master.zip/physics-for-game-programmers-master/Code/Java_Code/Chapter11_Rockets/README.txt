Compile commands  

javac RocketSimulator.java

