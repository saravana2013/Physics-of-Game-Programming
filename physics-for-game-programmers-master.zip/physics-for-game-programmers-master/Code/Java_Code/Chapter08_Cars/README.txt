Compile commands  

javac CarSimulator.java

