Compile commands  

javac FlightSimulator.java

