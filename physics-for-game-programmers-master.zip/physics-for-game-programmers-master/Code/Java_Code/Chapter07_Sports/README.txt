Compile commands  

javac GolfGame.java
javac FreeKick.java
javac FreeThrow.java

