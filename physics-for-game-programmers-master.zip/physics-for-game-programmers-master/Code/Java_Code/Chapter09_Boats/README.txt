Compile commands  

javac BoatSimulator.java

