Compile commands  

javac GolfGame.java
javac GolfGame2.java
javac GolfGame3.java
javac GolfGame4.java

