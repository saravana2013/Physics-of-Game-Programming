Compile commands  

javac PaddleGame.java
javac SphereCollision.java

