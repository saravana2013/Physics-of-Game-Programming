Compile commands  

javac GasTankSimulator.java

