Compile commands  

javac BeanBag.java
javac RK4Spring.java
javac SpringSimulator.java

