Compile commands  

javac GravityGame.java
javac Shuffleboard.java

