Compile commands (using cygwin gcc compiler) 

gcc GolfGame.c -o GolfGame.exe
gcc FreeKick.c -o FreeKick.exe
gcc FreeThrow.c -o FreeThrow.exe

