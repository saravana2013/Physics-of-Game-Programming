Compile commands (using cygwin gcc compiler) 

gcc GolfGame.c -o GolfGame.exe
gcc GolfGame2.c -o GolfGame2.exe
gcc GolfGame3.c -o GolfGame3.exe
gcc GolfGame4.c -o GolfGame4.exe

