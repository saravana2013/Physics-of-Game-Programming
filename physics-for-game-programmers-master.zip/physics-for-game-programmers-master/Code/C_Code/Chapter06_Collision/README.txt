Compile commands (using cygwin gcc compiler) 

gcc SphereCollision.c -o SphereCollision.exe


I didn't write a C version of the Paddle Game example
because there was no way that I could think of to
program the game without a GUI. You really have to be
able to move the paddle up and down to implement the
Paddle Game.


