Compile commands (using cygwin gcc compiler) 

gcc FlightSimulator.c -o FlightSimulator.exe

