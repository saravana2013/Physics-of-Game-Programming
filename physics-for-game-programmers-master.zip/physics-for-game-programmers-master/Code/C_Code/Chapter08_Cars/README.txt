Compile commands (using cygwin gcc compiler) 

gcc CarSimulator.c -o CarSimulator.exe

