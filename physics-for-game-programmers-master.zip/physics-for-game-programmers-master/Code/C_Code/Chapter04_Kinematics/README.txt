Compile commands (using cygwin gcc compiler) 

gcc RK4Spring.c -o RK4Spring.exe

