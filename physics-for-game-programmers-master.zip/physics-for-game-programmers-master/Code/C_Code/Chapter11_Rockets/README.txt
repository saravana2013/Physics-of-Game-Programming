Compile commands (using cygwin gcc compiler) 

gcc RocketSimulator.c -o RocketSimulator.exe

