Compile commands (using cygwin gcc compiler) 

gcc PiEstimator.c -o PiEstimator.exe
gcc SoldierGame.c -o SoldierGame.exe

