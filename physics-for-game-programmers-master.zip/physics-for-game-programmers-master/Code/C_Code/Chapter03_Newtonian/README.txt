Compile commands (using cygwin gcc compiler) 

gcc GravityGame.c -o GravityGame.exe
gcc Shuffleboard.c -o Shuffleboard.exe

