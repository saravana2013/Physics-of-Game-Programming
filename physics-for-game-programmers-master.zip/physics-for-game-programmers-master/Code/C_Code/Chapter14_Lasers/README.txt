Compile commands (using cygwin gcc compiler) 

gcc LaserSimulator.c -o LaserSimulator.exe

