Compile commands (using cygwin gcc compiler) 

gcc BoatSimulator.c -o BoatSimulator.exe

