Compile commands (using cygwin gcc compiler) 

gcc GasTankSimulator.c -o GasTankSimulator.exe

